public interface Samurai{
	

	public static final int SPEED = 13;
	public static final int RANGE = 40;
	public static final int TYPE = 25;
	public static final int CD = 4000;
	public static final int WW = 33;
	public static final int WL = 27;
	public static final String WEAPON = "Weapons/Sword/";
}