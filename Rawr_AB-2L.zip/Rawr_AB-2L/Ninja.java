public interface Ninja{


	public static final int SPEED = 7;
	public static final int RANGE = 15;
	public static final int TYPE = 15;
	public static final int CD = 5000;
	public static final String WEAPON = "Weapons/Dagger/";
	
}